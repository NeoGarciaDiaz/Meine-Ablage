﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace LOS
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public Random rnd = new Random();
        DispatcherTimer timer;
        pixel[] p;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            timer = new DispatcherTimer();
            timer.Tick += new EventHandler(timer_Tick);
            timer.Interval = new TimeSpan(0, 0, 0, 0, 1);



            timer.Start();
            //pixel ist 5*5 Pixel groß, sonst dauert das kompilieren zu lang
            p = new pixel[(int)(Wnd.Height * Wnd.Width)/5];
            //MessageBox.Show((Wnd.Height * Wnd.Width).ToString());
            //Wnd.Height
            int i3 = 0;
            for(int i2 = 0; i2 < Wnd.Height/5; i2++)
            {
                for (int i = 0; i < Wnd.Width/5; i++)
                {
                    
                    p[i3] = new pixel(i*5, i2*5);
                    p[i3].Draw(Cvs);
                    i3++;
                   
                }
            }
            
        }

        
        private void timer_Tick(object sender, EventArgs e)
        {
            
            foreach (pixel ok in p)
            {
                if(ok != null)
                {
                    int R = rnd.Next(255);
                    int G = rnd.Next(255);
                    int B = rnd.Next(255);

                    var brush = new SolidColorBrush(Color.FromArgb(255, (byte)R, (byte)G, (byte)B));


                    ok.Update(brush);
                }
                
                
            }
                    


        }

    }
}
