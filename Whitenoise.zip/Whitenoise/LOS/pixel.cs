﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace LOS
{
    class pixel
    {
        public Rectangle rect { get; set; }

        

        public pixel(double x, double y)
        {
            rect = new Rectangle();
            rect.Width = 5;
            rect.Height = 5;

            rect.Fill = Brushes.Green;

            

            Canvas.SetLeft(rect, x);
            Canvas.SetTop(rect, y);




        }

        public void Update(Brush b)
        {
            
                rect.Fill = b;
            
        }

        public void Draw(Canvas c)
        {
            if (!c.Children.Contains(rect))
            {
                c.Children.Add(rect);
            }
        }

        public void UnDraw(Canvas c)
        {
            if (c.Children.Contains(rect))
            {
                c.Children.Remove(rect);
            }
        }






    }
}
