﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;
using System.Drawing;
using System.Reflection.Emit;
using System.Diagnostics;

namespace TESTPROJ
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        string lastpress = "Down";
        int ticks = 0;
        DispatcherTimer timer;
        Random rnd = new Random();
        static int spalten = 20;
        static int anz = spalten * spalten;
        static int zeilen = anz / spalten;
        int anzp = 0, anzg = 0, banzp = 0;
        int showbumm = 0;
        projektil[] projektile = new projektil[100];
        bossprojektil[] bprojektile = new bossprojektil[100];
        pierce durch;
        bumm[] boom = new bumm[4];
        gegner[] gegner = new gegner[1000];
        boss bob;
        bool bossstage = false;
        feld[] felder = new feld[anz];
        bool containspierce = false;
        int x = 1, y = 1;


        int b = 3;
        int level = 1;

        int maxg = 5;

        int score = 0, currentlvlscore = 0, chain = 1;


        bool unsterblich = false;
        int unsterblichcounter = 0;

        Ellipse spieler = new Ellipse();
        int Radius = 20;
        Rectangle richtung = new Rectangle();
        int projneu = 0;
        int bprojneu = 0;
        bool keydown = false;
        string taste = "";
        private void wnd_KeyUp(object sender, KeyEventArgs e)
        {
            keydown = false;
        }
        
        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            taste = e.Key.ToString();
            
            if (e.DeadCharProcessedKey.ToString()!="None")
            {
                //MessageBox.Show(taste);
                taste = e.DeadCharProcessedKey.ToString();
            }

            

            if (keydown == false)
            {
                keydown = true;


                if (taste == "Right")
                {
                    x++;
                    if (y >= 1 && x >= 1 && x <= spalten && y <= zeilen)
                    {
                        Canvas.SetLeft(spieler, Canvas.GetLeft(spieler) + felder[0].rect.Width);
                        Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius * 2 - (richtung.Width));
                        Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius - (richtung.Height / 2));
                        lastpress = taste;
                    }
                    else
                    {
                        x--;
                    }

                }
                if (taste == "Left")
                {
                    x--;
                    if (y >= 1 && x >= 1 && x <= spalten && y <= zeilen)
                    {
                        Canvas.SetLeft(spieler, Canvas.GetLeft(spieler) - felder[0].rect.Width);
                        Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) - Radius + (richtung.Width * 2));
                        Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius - (richtung.Height / 2));
                        lastpress = taste;
                    }
                    else
                    {
                        x++;
                    }
                }
                if (taste == "Down")
                {
                    y++;
                    if (y >= 1 && x >= 1 && x <= spalten && y <= zeilen)
                    {
                        Canvas.SetTop(spieler, Canvas.GetTop(spieler) + felder[0].rect.Height);
                        Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius - (richtung.Width / 2));
                        Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius * 2 - (richtung.Height));
                        lastpress = taste;
                    }
                    else
                    {
                        y--;
                    }
                }
                if (taste == "Up")
                {
                    y--;
                    if (y >= 1 && x >= 1 && x <= spalten && y <= zeilen)
                    {
                        Canvas.SetTop(spieler, Canvas.GetTop(spieler) - felder[0].rect.Height);
                        Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius - (richtung.Width / 2));
                        Canvas.SetTop(richtung, Canvas.GetTop(spieler) - Radius + (richtung.Height * 2));
                        lastpress = taste;
                    }
                    else
                    {
                        y++;
                    }


                }
                if (taste == "Q" || taste == "q")
                {
                    if (b - 1 >= 0)
                    {
                        b--;
                        bullets.Content = "Bullets: " + b;

                        if (projneu < anzp)
                        {
                            projektile[projneu].UnDraw(Cvs);
                        }


                        projektile[projneu] = new projektil(Canvas.GetLeft(richtung) + 2.5, Canvas.GetTop(richtung) + 2.5, lastpress);
                        projektile[projneu].Draw(Cvs);

                        if (anzp < 100)
                        {
                            anzp++;
                        }

                        projneu++;

                        if (projneu >= 100)
                        {

                            projneu = 0;
                        }
                    }

                }
                if (taste == "W" || taste == "w")
                {

                    if (containspierce)
                    {
                        durch.UnDraw(Cvs);
                    }


                    durch = new pierce(Canvas.GetLeft(richtung) + 2.5, Canvas.GetTop(richtung) + 2.5, lastpress);
                    durch.Draw(Cvs);
                    containspierce = true;
                    chain = 1;

                }
                if (taste == "E" || taste == "e")
                {

                    if (unsterblichcounter == 0)
                    {
                        unsterblich = true;
                        spieler.Fill = Brushes.Cyan;
                    }






                }
                if (taste == "R" || taste == "r")
                {

                    if (showbumm == 0)
                    {
                        for (int i3 = 0; i3 < 4; i3++)
                        {
                            if (i3 == 0)
                            {
                                boom[i3] = new bumm(Canvas.GetLeft(spieler) - felder[0].rect.Width, Canvas.GetTop(spieler) - felder[0].rect.Height);
                            }
                            if (i3 == 1)
                            {
                                boom[i3] = new bumm(Canvas.GetLeft(spieler) + felder[0].rect.Width, Canvas.GetTop(spieler) + felder[0].rect.Height);
                            }
                            if (i3 == 2)
                            {
                                boom[i3] = new bumm(Canvas.GetLeft(spieler) + felder[0].rect.Width, Canvas.GetTop(spieler) - felder[0].rect.Height);
                            }
                            if (i3 == 3)
                            {
                                boom[i3] = new bumm(Canvas.GetLeft(spieler) - felder[0].rect.Width, Canvas.GetTop(spieler) + felder[0].rect.Height);
                            }
                            boom[i3].Draw(Cvs);
                            showbumm = 1;
                        }
                    }








                }
                if (taste == "Tab")
                {

                    if (lastpress == "Right")
                    {

                        Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius - (richtung.Width / 2));
                        Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius * 2 - (richtung.Height));
                        lastpress = "Down";


                    }
                    else if (lastpress == "Down")
                    {
                        Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) - Radius + (richtung.Width * 2));
                        Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius - (richtung.Height / 2));
                        lastpress = "Left";
                    }
                    else if (lastpress == "Left")
                    {
                        Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius - (richtung.Width / 2));
                        Canvas.SetTop(richtung, Canvas.GetTop(spieler) - Radius + (richtung.Height * 2));
                        lastpress = "Up";
                    }
                    else if (lastpress == "Up")
                    {
                        Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius * 2 - (richtung.Width));
                        Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius - (richtung.Height / 2));
                        lastpress = "Right";
                    }

                }
                if (taste == "T" || taste == "t")
                {

                    if (lastpress == "Right")
                    {
                        Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius - (richtung.Width / 2));
                        Canvas.SetTop(richtung, Canvas.GetTop(spieler) - Radius + (richtung.Height * 2));
                        lastpress = "Up";


                    }
                    else if (lastpress == "Down")
                    {
                        Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius * 2 - (richtung.Width));
                        Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius - (richtung.Height / 2));
                        lastpress = "Right";
                        
                    }
                    else if (lastpress == "Left")
                    {

                        Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius - (richtung.Width / 2));
                        Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius * 2 - (richtung.Height));
                        lastpress = "Down";
                    }
                    else if (lastpress == "Up")
                    {

                        Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) - Radius + (richtung.Width * 2));
                        Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius - (richtung.Height / 2));
                        lastpress = "Left";
                    }

                }


            }


        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {






            bullets.Content = "Bullets: " + b;

            for (int i = 0; i < anz; i++)
            {
                felder[i] = new feld(x, y);
                felder[i].Draw(Cvs);
                x++;
                if (x > spalten)
                {
                    x = 1;
                    y++;
                }
            }









            timer = new DispatcherTimer();
            timer.Tick += new EventHandler(timer_Tick);
            timer.Interval = new TimeSpan(0, 0, 0, 0, 15);



            timer.Start();





            spieler.Width = 2 * Radius;
            spieler.Height = 2 * Radius;
            spieler.Fill = Brushes.Blue;

            x = 1;
            y = 1;

            Canvas.SetLeft(spieler, Canvas.GetLeft(felder[0].rect) + felder[0].rect.Width / 2 - Radius);
            Canvas.SetTop(spieler, Canvas.GetTop(felder[0].rect) + felder[0].rect.Height / 2 - Radius);
            Cvs.Children.Add(spieler);


            richtung.Width = 10;
            richtung.Height = 10;
            richtung.Fill = Brushes.Red;
            Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius - (richtung.Width / 2));
            Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius * 2 - (richtung.Height));
            Cvs.Children.Add(richtung);



            int[] xr = new int[maxg];
            int[] yr = new int[maxg];
            string[] strings = new string[maxg];
            string[] result = new string[maxg];
            do
            {
                for (int i = 0; i < maxg; i++)
                {
                    int x = (rnd.Next(0, 6) + (spalten) / 2 - 3);
                    int y = (rnd.Next(0, 6) + (spalten) / 2 - 3) * spalten;
                    xr[i] = x;
                    yr[i] = y;
                    strings[i] = xr[i].ToString() + yr[i].ToString();

                }

                if (maxg <= 12)
                {
                    result = strings.Distinct().ToArray();
                }
                else
                {
                    result = strings.ToArray();
                }



            } while (result.Count() != maxg);




            for (anzg = 0; anzg < maxg; anzg++)
            {









                gegner[anzg] = new gegner(Canvas.GetLeft(felder[xr[anzg]].rect) + felder[xr[anzg]].rect.Width / 2 - 15, Canvas.GetTop(felder[yr[anzg]].rect) + felder[yr[anzg]].rect.Height / 2 - 15);

                gegner[anzg].Draw(Cvs);






            }


        }

        private void timer_Tick(object sender, EventArgs e)
        {
            ticks++;




            int i = 0;
            if (unsterblich == false)
            {
                foreach (gegner g in gegner)
                {
                    if (i < anzg)
                    {
                        if (gegner[i] != null)
                        {

                            if (gegner[i].Hurtbox(Cvs, spieler, level) == 1)
                            {
                                if (showbumm > 0)
                                {
                                    for (int i3 = 0; i3 < 4; i3++)
                                    {



                                        showbumm = 0;
                                        boom[i3].UnDraw(Cvs);
                                    }
                                }
                                currentlvlscore = 0;
                                score = score + currentlvlscore;
                                unsterblichcounter = 0;
                                spieler.Fill = Brushes.Blue;
                                int remove = 0;
                                foreach (gegner gn in gegner)
                                {
                                    if (remove < anzg)
                                    {
                                        if (Cvs.Children.Contains(gegner[remove].rect))
                                        {
                                            gegner[remove].UnDraw(Cvs);
                                        }

                                    }

                                    remove++;
                                }
                                remove = 0;
                                foreach (projektil pn in projektile)
                                {
                                    if (remove < anzp)
                                    {
                                        if (Cvs.Children.Contains(projektile[remove].rect))
                                        {
                                            projektile[remove].UnDraw(Cvs);
                                        }

                                    }

                                    remove++;
                                }

                                remove = 0;
                                foreach (bossprojektil pn in bprojektile)
                                {
                                    if (remove < banzp)
                                    {
                                        if (Cvs.Children.Contains(bprojektile[remove].rect))
                                        {
                                            bprojektile[remove].UnDraw(Cvs);
                                        }

                                    }

                                    remove++;
                                }

                                if (containspierce)
                                {
                                    durch.UnDraw(Cvs);
                                }

                                Cvs.Children.Remove(richtung);
                                Cvs.Children.Add(spieler);
                                Cvs.Children.Add(richtung);
                                b = 3;
                                bullets.Content = "Bullets: " + b;
                                x = 1;
                                y = 1;
                                ticks = 1;
                                lastpress = "Down";
                                Canvas.SetLeft(spieler, Canvas.GetLeft(felder[0].rect) + felder[0].rect.Width / 2 - Radius);
                                Canvas.SetTop(spieler, Canvas.GetTop(felder[0].rect) + felder[0].rect.Height / 2 - Radius);
                                Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius - (richtung.Width / 2));
                                Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius * 2 - (richtung.Height));
                                int[] xr = new int[maxg];
                                int[] yr = new int[maxg];
                                string[] strings = new string[maxg];
                                string[] result = new string[maxg];
                                do
                                {
                                    for (i = 0; i < maxg; i++)
                                    {
                                        int x = (rnd.Next(0, 6) + (spalten) / 2 - 3);
                                        int y = (rnd.Next(0, 6) + (spalten) / 2 - 3) * spalten;
                                        xr[i] = x;
                                        yr[i] = y;
                                        strings[i] = xr[i].ToString() + yr[i].ToString();

                                    }
                                    if (maxg <= 12)
                                    {
                                        result = strings.Distinct().ToArray();
                                    }
                                    else
                                    {
                                        result = strings.ToArray();
                                    }

                                } while (result.Count() != maxg);




                                for (anzg = 0; anzg < maxg; anzg++)
                                {
                                    gegner[anzg] = new gegner(Canvas.GetLeft(felder[xr[anzg]].rect) + felder[xr[anzg]].rect.Width / 2 - 15, Canvas.GetTop(felder[yr[anzg]].rect) + felder[yr[anzg]].rect.Height / 2 - 15);
                                    gegner[anzg].Draw(Cvs);
                                }
                            }
                        }

                    }

                    i++;
                }
                

            }
            else
            {
                unsterblichcounter++;
            }

                if (unsterblichcounter >= 375)
                {
                    unsterblich = false;
                    spieler.Fill = Brushes.Yellow;
                    unsterblichcounter++;
                    if (unsterblichcounter >= 750)
                    {
                        unsterblichcounter = 0;
                        spieler.Fill = Brushes.Blue;
                    }

                }

            if (bossstage == true)
            {
                if (bob.Hurtbox(Cvs, spieler, level) == 1)
                {
                    if (showbumm > 0)
                    {
                        for (int i3 = 0; i3 < 4; i3++)
                        {



                            showbumm = 0;
                            boom[i3].UnDraw(Cvs);
                        }
                    }
                    currentlvlscore = 0;
                    score = score + currentlvlscore;
                    unsterblichcounter = 0;
                    unsterblich = false;
                    spieler.Fill = Brushes.Blue;


                    if (Cvs.Children.Contains(bob.rect))
                    {
                        bob.UnDraw(Cvs);
                    }

                    int remove = 0;
                    foreach (projektil pn in projektile)
                    {
                        if (remove < anzp)
                        {
                            if (Cvs.Children.Contains(projektile[remove].rect))
                            {
                                projektile[remove].UnDraw(Cvs);
                            }

                        }

                        remove++;
                    }

                    remove = 0;
                    foreach (bossprojektil pn in bprojektile)
                    {
                        if (remove < banzp)
                        {
                            if (Cvs.Children.Contains(bprojektile[remove].rect))
                            {
                                bprojektile[remove].UnDraw(Cvs);
                            }

                        }

                        remove++;
                    }

                    if (containspierce)
                    {
                        durch.UnDraw(Cvs);
                    }

                    Cvs.Children.Remove(richtung);
                    Cvs.Children.Add(spieler);
                    Cvs.Children.Add(richtung);
                    b = 3;
                    bullets.Content = "Bullets: " + b;
                    x = 1;
                    y = 1;
                    ticks = 1;
                    lastpress = "Down";
                    Canvas.SetLeft(spieler, Canvas.GetLeft(felder[0].rect) + felder[0].rect.Width / 2 - Radius);
                    Canvas.SetTop(spieler, Canvas.GetTop(felder[0].rect) + felder[0].rect.Height / 2 - Radius);
                    Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius - (richtung.Width / 2));
                    Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius * 2 - (richtung.Height));

                    bob = new boss(Canvas.GetLeft(felder[anz - 1].rect) + felder[anz - 1].rect.Width / 2 - 15, Canvas.GetTop(felder[anz - 1].rect) + felder[anz - 1].rect.Height / 2 - 15, 10);
                    bob.Draw(Cvs);


                }

            }

            int kills = 0;
                i = 0;
                foreach (gegner g in gegner)
                {
                    if (i < anzg)
                    {
                        if (!Cvs.Children.Contains(gegner[i].rect))
                        {
                            kills++;
                        }

                    }

                    i++;
                }

                if (bossstage == true)
                {
                    kills = 0;
                    if (!Cvs.Children.Contains(bob.rect))
                    {
                        kills = anzg;
                    }
                }

                if (kills == anzg)
                {
                    level++;
                    levellabel.Content = "Level: " + level;

                    unsterblich = false;
                    maxg = maxg + level - 1;
                    MessageBox.Show("LEVEL: " + level);
                    score = score + currentlvlscore;
                    kills = 0;
                    unsterblichcounter = 0;
                    spieler.Fill = Brushes.Blue;

                    if (showbumm > 0)
                    {
                        for (int i3 = 0; i3 < 4; i3++)
                        {



                            showbumm = 0;
                            boom[i3].UnDraw(Cvs);
                        }
                    }

                    if (containspierce)
                    {
                        durch.UnDraw(Cvs);
                    }


                    b = 3;
                    bullets.Content = "Bullets: " + b;
                    x = 1;
                    y = 1;
                    ticks = 1;
                    lastpress = "Down";
                    Canvas.SetLeft(spieler, Canvas.GetLeft(felder[0].rect) + felder[0].rect.Width / 2 - Radius);
                    Canvas.SetTop(spieler, Canvas.GetTop(felder[0].rect) + felder[0].rect.Height / 2 - Radius);
                    Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius - (richtung.Width / 2));
                    Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius * 2 - (richtung.Height));


                    if (level%5 == 0)
                    {
                        bossstage = true;
                    }
                    else
                    {
                        bossstage = false;
                    }

                    if (bossstage == false)
                    {
                        int[] xr = new int[maxg];
                        int[] yr = new int[maxg];
                        string[] strings = new string[maxg];
                        string[] result = new string[maxg];
                        do
                        {
                            for (i = 0; i < maxg; i++)
                            {
                                int x = (rnd.Next(0, 6) + (spalten) / 2 - 3);
                                int y = (rnd.Next(0, 6) + (spalten) / 2 - 3) * spalten;
                                xr[i] = x;
                                yr[i] = y;
                                strings[i] = xr[i].ToString() + yr[i].ToString();

                            }
                            if (maxg <= 12)
                            {
                                result = strings.Distinct().ToArray();
                            }
                            else
                            {
                                result = strings.ToArray();
                            }

                        } while (result.Count() != maxg);




                        for (anzg = 0; anzg < maxg; anzg++)
                        {
                            gegner[anzg] = new gegner(Canvas.GetLeft(felder[xr[anzg]].rect) + felder[xr[anzg]].rect.Width / 2 - 15, Canvas.GetTop(felder[yr[anzg]].rect) + felder[yr[anzg]].rect.Height / 2 - 15);

                            gegner[anzg].Draw(Cvs);

                        }
                    }
                    else
                    {
                        bob = new boss(Canvas.GetLeft(felder[anz - 1].rect) + felder[anz - 1].rect.Width / 2 - 15, Canvas.GetTop(felder[anz - 1].rect) + felder[anz - 1].rect.Height / 2 - 15, 10*(level/5));
                        bob.Draw(Cvs);
                    }

                    

                    int remove = 0;
                    foreach (projektil pn in projektile)
                    {
                        if (remove < anzp)
                        {
                            if (Cvs.Children.Contains(projektile[remove].rect))
                            {
                                projektile[remove].UnDraw(Cvs);
                            }

                        }

                        remove++;
                    }
                remove = 0;
                foreach (bossprojektil pn in bprojektile)
                {
                    if (remove < banzp)
                    {
                        if (Cvs.Children.Contains(bprojektile[remove].rect))
                        {
                            bprojektile[remove].UnDraw(Cvs);
                        }

                    }

                    remove++;
                }

            }




                




                if (ticks % 100 == 0)
                {
                    if (b < 3)
                    {
                        b++;
                        bullets.Content = "Bullets: " + b;
                    }
                }
                i = 0;

                int gegnergeschw = 160 - (level * 2);

            if(bossstage == true)
            {
                gegnergeschw = gegnergeschw / 2;
            }


                if (ticks % gegnergeschw == 0)
                {

                    int gegnerbewegung;
                    
                
                if(bossstage==true)
                {
                    gegnerbewegung = (rnd.Next(1, 3));
                    string bossrichtung = "";
                    if (Canvas.GetTop(bob.rect) < Canvas.GetTop(spieler) && Canvas.GetLeft(bob.rect) < Canvas.GetLeft(spieler))
                    {
                        
                        if (gegnerbewegung == 1)
                        {
                            Canvas.SetTop(bob.rect, Canvas.GetTop(bob.rect) + felder[0].rect.Height);
                            bossrichtung = "Down";
                        }
                        else
                        {
                            Canvas.SetLeft(bob.rect, Canvas.GetLeft(bob.rect) + felder[0].rect.Height);
                            bossrichtung = "Right";
                        }

                    }else if(Canvas.GetTop(bob.rect) < Canvas.GetTop(spieler) && Canvas.GetLeft(bob.rect) - (bob.rect.Width / 2) > Canvas.GetLeft(spieler))
                    {
                        if (gegnerbewegung == 1)
                        {
                            Canvas.SetTop(bob.rect, Canvas.GetTop(bob.rect) + felder[0].rect.Height);
                            bossrichtung = "Down";
                        }
                        else
                        {
                            Canvas.SetLeft(bob.rect, Canvas.GetLeft(bob.rect) - felder[0].rect.Height);
                            bossrichtung = "Left";
                        }
                    }
                    else if(Canvas.GetTop(bob.rect) - (bob.rect.Height / 2) > Canvas.GetTop(spieler) && Canvas.GetLeft(bob.rect) < Canvas.GetLeft(spieler))
                    {
                        if (gegnerbewegung == 1)
                        {
                            Canvas.SetTop(bob.rect, Canvas.GetTop(bob.rect) - felder[0].rect.Height);
                            bossrichtung = "Up";
                        }
                        else
                        {
                            Canvas.SetLeft(bob.rect, Canvas.GetLeft(bob.rect) + felder[0].rect.Height);
                            bossrichtung = "Right";
                        }
                    }
                    else if(Canvas.GetTop(bob.rect)-(bob.rect.Height/2) > Canvas.GetTop(spieler) && Canvas.GetLeft(bob.rect) - (bob.rect.Width / 2) > Canvas.GetLeft(spieler))
                    {
                        
                        if (gegnerbewegung == 1)
                        {
                            Canvas.SetTop(bob.rect, Canvas.GetTop(bob.rect) - felder[0].rect.Height);
                            bossrichtung = "Up";
                        }
                        else
                        {
                            Canvas.SetLeft(bob.rect, Canvas.GetLeft(bob.rect) - felder[0].rect.Height);
                            bossrichtung = "Left";
                        }
                    }
                    else if(Canvas.GetTop(bob.rect) < Canvas.GetTop(spieler))
                    {
                        Canvas.SetTop(bob.rect, Canvas.GetTop(bob.rect) + felder[0].rect.Height);
                        bossrichtung = "Down";
                    }
                    else if(Canvas.GetTop(bob.rect) - (bob.rect.Height / 2) > Canvas.GetTop(spieler))
                    {
                        Canvas.SetTop(bob.rect, Canvas.GetTop(bob.rect) - felder[0].rect.Height);
                        bossrichtung = "Up";
                    }
                    else if(Canvas.GetLeft(bob.rect) < Canvas.GetLeft(spieler))
                    {
                        Canvas.SetLeft(bob.rect, Canvas.GetLeft(bob.rect) + felder[0].rect.Height);
                        bossrichtung = "Right";
                    }
                    else if (Canvas.GetLeft(bob.rect) - (bob.rect.Width / 2) > Canvas.GetLeft(spieler))
                    {
                        Canvas.SetLeft(bob.rect, Canvas.GetLeft(bob.rect) - felder[0].rect.Height);
                        bossrichtung = "Left";
                    }
                    

                    if (bossrichtung == "Right")
                    {
                        Canvas.SetLeft(bob.gun, Canvas.GetLeft(bob.rect) + (bob.rect.Width/2) * 2 - (bob.gun.Width/2));
                        Canvas.SetTop(bob.gun, Canvas.GetTop(bob.rect) + (bob.rect.Height/2) - (bob.gun.Height / 2 ));

                    }
                    if (bossrichtung == "Left")
                    {
                      
                        Canvas.SetLeft(bob.gun, Canvas.GetLeft(bob.rect) - (bob.rect.Width / 2) + ((bob.gun.Width / 2) * 2));
                        Canvas.SetTop(bob.gun, Canvas.GetTop(bob.rect) + (bob.rect.Height/2) - (bob.gun.Height /2 ));


                    }
                    if (bossrichtung == "Down")
                    {
                        Canvas.SetLeft(bob.gun, Canvas.GetLeft(bob.rect) + (bob.rect.Width/2) - (bob.gun.Width/2 ));
                        Canvas.SetTop(bob.gun, Canvas.GetTop(bob.rect) + (bob.rect.Height /2)* 2 - (bob.gun.Height / 2));


                    }
                    if (bossrichtung == "Up")
                    {
                        Canvas.SetLeft(bob.gun, Canvas.GetLeft(bob.rect) + (bob.rect.Width/2) - (bob.gun.Width / 2));
                        Canvas.SetTop(bob.gun, Canvas.GetTop(bob.rect) - (bob.rect.Height/2) + ((bob.gun.Height/2) * 2));


                    }



                    if (bprojneu < banzp)
                    {
                        bprojektile[bprojneu].UnDraw(Cvs);
                    }
                    

                    bprojektile[bprojneu] = new bossprojektil(Canvas.GetLeft(bob.gun) + 2.5, Canvas.GetTop(bob.gun) + 2.5, bossrichtung);
                    bprojektile[bprojneu].Draw(Cvs);
                    
                    if (banzp < 100)
                    {
                        banzp++;
                    }

                    

                    bprojneu++;

                    if (bprojneu >= 100)
                    {

                        bprojneu = 0;
                    }




                }



                    foreach (gegner g in gegner)
                    {
                        if (i < anzg)
                        {
                            gegnerbewegung = (rnd.Next(1, 5));
                            switch (gegnerbewegung)
                            {
                                case 1:
                                    if (Convert.ToInt32(Canvas.GetTop(gegner[i].rect) - felder[0].rect.Height) >= Convert.ToInt32(Canvas.GetTop(felder[0].rect)))
                                    {
                                        Canvas.SetTop(gegner[i].rect, Canvas.GetTop(gegner[i].rect) - felder[0].rect.Height);
                                    }

                                    break;
                                case 2:
                                    if (Convert.ToInt32(Canvas.GetLeft(gegner[i].rect) - felder[0].rect.Width) >= Convert.ToInt32(Canvas.GetLeft(felder[0].rect)))
                                    {
                                        Canvas.SetLeft(gegner[i].rect, Canvas.GetLeft(gegner[i].rect) - felder[0].rect.Width);
                                    }

                                    break;
                                case 3:
                                    if (Convert.ToInt32(Canvas.GetLeft(gegner[i].rect) + felder[0].rect.Width) <= Convert.ToInt32(Canvas.GetLeft(felder[spalten - 1].rect) + felder[spalten - 1].rect.Width))
                                    {
                                        Canvas.SetLeft(gegner[i].rect, Canvas.GetLeft(gegner[i].rect) + felder[0].rect.Width);
                                    }
                                    break;
                                case 4:
                                    if (Convert.ToInt32(Canvas.GetTop(gegner[i].rect) + felder[0].rect.Height) <= Convert.ToInt32(Canvas.GetTop(felder[anz - 1].rect) + felder[anz - 1].rect.Height))
                                    {
                                        Canvas.SetTop(gegner[i].rect, Canvas.GetTop(gegner[i].rect) + felder[0].rect.Height);
                                    }
                                    break;
                            }
                        }
                        i++;
                    }




                }

                
                int i2 = 0;

                if (containspierce)
                {
                    durch.Update();
                    foreach (gegner g in gegner)
                    {
                        if (i2 < anzg)
                        {

                            if (bossstage == true)
                            {
                                if (bob.Update(Cvs, durch.rect))
                                {
                                    durch.UnDraw(Cvs);
                                }
                            }else if (gegner[i2].Update2(Cvs, durch))
                            {
                                currentlvlscore = currentlvlscore + (10 * chain);
                                chain++;
                                Scorelabel.Content = "Score: " + (score + currentlvlscore);
                            }
                            
                        }
                        i2++;
                    }
                }



            i = 0;
            i2 = 0;

                foreach (projektil p in projektile)
                {
                    if (i < anzp)
                    {
                        projektile[i].Update();
                        i2 = 0;
                        foreach (gegner g in gegner)
                        {
                            if (i2 < anzg)
                            {
                                if (bossstage == true)
                                {
                                    if (bob.Update(Cvs, projektile[i].rect))
                                    {
                                        projektile[i].UnDraw(Cvs);
                                    }
                                }
                                else if (gegner[i2].Update(Cvs, projektile[i]))
                                    {
                                        currentlvlscore = currentlvlscore + 30;
                                        Scorelabel.Content = "Score: " + (score + currentlvlscore);
                                    }

                            }
                            i2++;
                        }
                    }

                    i++;
                }

            i = 0;
            foreach (bossprojektil p in bprojektile)
            {
                

                if (i < banzp)
                {
                    
                    bprojektile[i].Update();
                    if (unsterblich == false)
                    {
                        if (bprojektile[i].Hurtbox(Cvs, spieler, level) == 1)
                        {
                            if (showbumm > 0)
                            {
                                for (int i3 = 0; i3 < 4; i3++)
                                {



                                    showbumm = 0;
                                    boom[i3].UnDraw(Cvs);
                                }
                            }
                            currentlvlscore = 0;
                            score = score + currentlvlscore;
                            unsterblichcounter = 0;
                            spieler.Fill = Brushes.Blue;


                            if (Cvs.Children.Contains(bob.rect))
                            {
                                bob.UnDraw(Cvs);
                            }

                            int remove = 0;
                            foreach (projektil pn in projektile)
                            {
                                if (remove < anzp)
                                {
                                    if (Cvs.Children.Contains(projektile[remove].rect))
                                    {
                                        projektile[remove].UnDraw(Cvs);
                                    }

                                }

                                remove++;
                            }
                            remove = 0;
                            foreach (bossprojektil pn in bprojektile)
                            {
                                if (remove < banzp)
                                {
                                    if (Cvs.Children.Contains(bprojektile[remove].rect))
                                    {
                                        bprojektile[remove].UnDraw(Cvs);
                                    }

                                }

                                remove++;
                            }



                            if (containspierce)
                            {
                                durch.UnDraw(Cvs);
                            }

                            Cvs.Children.Remove(richtung);
                            Cvs.Children.Add(spieler);
                            Cvs.Children.Add(richtung);
                            b = 3;
                            bullets.Content = "Bullets: " + b;
                            x = 1;
                            y = 1;
                            ticks = 1;
                            lastpress = "Down";
                            Canvas.SetLeft(spieler, Canvas.GetLeft(felder[0].rect) + felder[0].rect.Width / 2 - Radius);
                            Canvas.SetTop(spieler, Canvas.GetTop(felder[0].rect) + felder[0].rect.Height / 2 - Radius);
                            Canvas.SetLeft(richtung, Canvas.GetLeft(spieler) + Radius - (richtung.Width / 2));
                            Canvas.SetTop(richtung, Canvas.GetTop(spieler) + Radius * 2 - (richtung.Height));

                            bob = new boss(Canvas.GetLeft(felder[anz - 1].rect) + felder[anz - 1].rect.Width / 2 - 15, Canvas.GetTop(felder[anz - 1].rect) + felder[anz - 1].rect.Height / 2 - 15, 10 * (level / 5));
                            bob.Draw(Cvs);

                        }
                    }
                }

                i++;
            }



            if (showbumm > 0)
                {
                    for (int i3 = 0; i3 < 4; i3++)
                    {
                        i2 = 0;
                        foreach (gegner g in gegner)
                        {
                            if (i2 < anzg)
                            {
                                if (bossstage == true)
                                {
                                    if (bob.Update(Cvs, boom[i3].rect))
                                    {
                                        boom[i3].UnDraw(Cvs);
                                    }
                                }
                                else if (gegner[i2].Update3(Cvs, boom[i3]))
                                {
                                    currentlvlscore = currentlvlscore + 15;
                                    Scorelabel.Content = "Score: " + (score + currentlvlscore);
                                }

                            }
                            i2++;
                        }
                    }
                    showbumm++;
                }

                if (showbumm > 10)
                {
                    showbumm = 0;
                    for (int i3 = 0; i3 < 4; i3++)
                    {




                        boom[i3].UnDraw(Cvs);
                    }
                }


            }
        }
    }

