﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace TESTPROJ
{
    internal class feld
    {
        public Rectangle rect { get; set; }
        public int idx { get; set; }

        public int idy { get; set; }
        public feld(int x, int y)
        {
            rect = new Rectangle();
            rect.Width = 50;
            rect.Height = 50;
            
            rect.Stroke = Brushes.Black;

            idx = x;
            idy = y;

            Canvas.SetLeft(rect, 50 * x);
            Canvas.SetTop(rect, 50 * y);
        }
        public void Draw(Canvas c)
        {
            if (!c.Children.Contains(rect))
            {
                c.Children.Add(rect);
            }
        }

        public void UnDraw(Canvas c)
        {
            if (c.Children.Contains(rect))
            {
                c.Children.Remove(rect);
            }
        }
    }
}