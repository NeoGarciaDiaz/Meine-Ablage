﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Drawing;
using System.Windows;
using System.Xml.Linq;

namespace TESTPROJ
{
    class gegner
    {
        public Rectangle rect { get; set; }

        public gegner(double x, double y)
        {
            rect = new Rectangle();
            rect.Width = 30;
            rect.Height = 30;

            rect.Fill = Brushes.Red;
           

            Canvas.SetLeft(rect, x);
            Canvas.SetTop(rect, y);




        }

        public bool Update(Canvas c, projektil p)
        {
            
            
            Rect r1 = new Rect(Canvas.GetLeft(rect), Canvas.GetTop(rect), rect.ActualWidth, rect.ActualHeight);
            Rect r2 = new Rect(Canvas.GetLeft(p.rect), Canvas.GetTop(p.rect), p.rect.ActualWidth, p.rect.ActualHeight);

            if (r1.IntersectsWith(r2))
            {
                if (c.Children.Contains(rect) && c.Children.Contains(p.rect))
                {
                    c.Children.Remove(rect);
                    p.UnDraw(c);
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }


        public bool Update2(Canvas c, pierce p)
        {


            Rect r1 = new Rect(Canvas.GetLeft(rect), Canvas.GetTop(rect), rect.ActualWidth, rect.ActualHeight);
            Rect r2 = new Rect(Canvas.GetLeft(p.rect), Canvas.GetTop(p.rect), p.rect.ActualWidth, p.rect.ActualHeight);

            if (r1.IntersectsWith(r2))
            {
                if (c.Children.Contains(rect) && c.Children.Contains(p.rect))
                {
                    c.Children.Remove(rect);
                    return true;
                }
                else
                {
                    return false;
                }

            }
            else
            {
                return false;
            }
        }

        public bool Update3(Canvas c, bumm b)
        {


            Rect r1 = new Rect(Canvas.GetLeft(rect), Canvas.GetTop(rect), rect.ActualWidth, rect.ActualHeight);
            Rect r2 = new Rect(Canvas.GetLeft(b.rect), Canvas.GetTop(b.rect), b.rect.ActualWidth, b.rect.ActualHeight);

            if (r1.IntersectsWith(r2))
            {
                if (c.Children.Contains(rect) && c.Children.Contains(b.rect))
                {
                    c.Children.Remove(rect);
                    return true;
                }
                else
                {
                    return false;
                }

            }
            else
            {
                return false;
            }
        }

        public int Hurtbox(Canvas c, Ellipse e, int level)
        {

            Rect r1 = new Rect(Canvas.GetLeft(rect), Canvas.GetTop(rect), rect.ActualWidth, rect.ActualHeight);
            Rect r2 = new Rect(Canvas.GetLeft(e), Canvas.GetTop(e), e.ActualWidth, e.ActualHeight);

            if (r1.IntersectsWith(r2))
            {
                if (c.Children.Contains(rect))
                {
                   c.Children.Remove(e);
                   MessageBox.Show("VERLOREN BEI LEVEL "+level);

                    return (1);
                }
                
                    
               
                
            }
            
                return (0);
            
                
            
        }




            public void Draw(Canvas c)
        {
            if (!c.Children.Contains(rect))
            {
                c.Children.Add(rect);
            }
        }

        public void UnDraw(Canvas c)
        {
            if (c.Children.Contains(rect))
            {
                c.Children.Remove(rect);
            }
        }



    }
}
