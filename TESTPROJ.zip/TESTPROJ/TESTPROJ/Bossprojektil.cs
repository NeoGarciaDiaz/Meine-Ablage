﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace TESTPROJ
{
    class bossprojektil
    {

        public Rectangle rect { get; set; }

        public string richtung { get; set; }

        public bossprojektil(double x, double y, string direction)
        {
            rect = new Rectangle();
            rect.Width = 5;
            rect.Height = 5;

            rect.Fill = Brushes.Violet;
            richtung = direction;


            Canvas.SetLeft(rect, x);
            Canvas.SetTop(rect, y);
        }

        public void Update()
        {
            

            if (richtung == "Up")
            {
                Canvas.SetTop(rect, Canvas.GetTop(rect) - 1);
            }
            if (richtung == "Down")
            {
                Canvas.SetTop(rect, Canvas.GetTop(rect) + 1);
            }
            if (richtung == "Left")
            {
                Canvas.SetLeft(rect, Canvas.GetLeft(rect) - 1);
            }
            if (richtung == "Right")
            {
                Canvas.SetLeft(rect, Canvas.GetLeft(rect) + 1);
            }

        }

        public void Draw(Canvas c)
        {
            if (!c.Children.Contains(rect))
            {
                c.Children.Add(rect);
            }
        }

        public void UnDraw(Canvas c)
        {
            if (c.Children.Contains(rect))
            {
                c.Children.Remove(rect);
            }
        }

        public int Hurtbox(Canvas c, Ellipse e, int level)
        {

            Rect r1 = new Rect(Canvas.GetLeft(rect), Canvas.GetTop(rect), rect.ActualWidth, rect.ActualHeight);
            Rect r2 = new Rect(Canvas.GetLeft(e), Canvas.GetTop(e), e.ActualWidth, e.ActualHeight);

            if (r1.IntersectsWith(r2))
            {
                if (c.Children.Contains(rect))
                {
                    c.Children.Remove(e);
                    MessageBox.Show("VERLOREN BEI LEVEL " + level);

                    return (1);
                }




            }

            return (0);
        }


    }
}
