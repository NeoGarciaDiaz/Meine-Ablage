﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace TESTPROJ
{
    internal class projektil
    {
        public Rectangle rect { get; set; }

        public string richtung { get; set; }

        public projektil(double x, double y, string direction)
        {
            rect = new Rectangle();
            rect.Width = 5;
            rect.Height = 5;

            rect.Fill = Brushes.Green;
            richtung = direction;
            

            Canvas.SetLeft(rect, x);
            Canvas.SetTop(rect, y);




        }

        public void Update()
        {
            if(richtung=="Up")
            {
                Canvas.SetTop(rect, Canvas.GetTop(rect)-1);
            }
            if (richtung == "Down")
            {
                Canvas.SetTop(rect, Canvas.GetTop(rect) + 1);
            }
            if (richtung == "Left")
            {
                Canvas.SetLeft(rect, Canvas.GetLeft(rect) - 1);
            }
            if (richtung == "Right")
            {
                Canvas.SetLeft(rect, Canvas.GetLeft(rect) + 1);
            }

        }

        public void Draw(Canvas c)
        {
            if (!c.Children.Contains(rect))
            {
                c.Children.Add(rect);
            }
        }

        public void UnDraw(Canvas c)
        {
            if (c.Children.Contains(rect))
            {
                c.Children.Remove(rect);
            }
        }






    }
}
