﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace TESTPROJ
{
    internal class bumm
    {


        public Rectangle rect { get; set; }

        

        public bumm(double x, double y)
        {
            rect = new Rectangle();
            
                rect.Width = 20;
                rect.Height = 20;
           

            rect.Fill = Brushes.Pink;
            

            Canvas.SetLeft(rect, x+ (rect.Width/2));
            Canvas.SetTop(rect, y+ (rect.Height / 2));




        }

        

        public void Draw(Canvas c)
        {
            if (!c.Children.Contains(rect))
            {
                c.Children.Add(rect);
            }
        }

        public void UnDraw(Canvas c)
        {
            if (c.Children.Contains(rect))
            {
                c.Children.Remove(rect);
            }
        }




    }
}
