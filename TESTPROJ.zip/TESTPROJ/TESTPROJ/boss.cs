﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows;

namespace TESTPROJ
{
    internal class boss
    {
        public double health { get; set; }
        public Rectangle rect { get; set; }
        public Rectangle gun { get; set; }
        public boss(double x, double y, double h)
        {
            rect = new Rectangle();
            rect.Width = 30;
            rect.Height = 30;

            rect.Fill = Brushes.OrangeRed;

            health = h;

            gun = new Rectangle();
            gun.Width = 10;
            gun.Height = 10;

            gun.Fill= Brushes.Yellow;

            Canvas.SetLeft(rect, x);
            Canvas.SetTop(rect, y);

            Canvas.SetLeft(gun, Canvas.GetLeft(rect) + (rect.Width/2) - (gun.Width /2));
            Canvas.SetTop(gun, Canvas.GetTop(rect) - (rect.Height/2) + ((gun.Height/2) * 2));


        }

        

        public int Hurtbox(Canvas c, Ellipse e, int level)
        {
            
            Rect r1 = new Rect(Canvas.GetLeft(rect), Canvas.GetTop(rect), rect.ActualWidth, rect.ActualHeight);
            Rect r2 = new Rect(Canvas.GetLeft(e), Canvas.GetTop(e), e.ActualWidth, e.ActualHeight);

            if (r1.IntersectsWith(r2))
            {
                if (c.Children.Contains(rect))
                {
                    c.Children.Remove(e);
                    MessageBox.Show("VERLOREN BEI LEVEL " + level);

                    return (1);
                }




            }

            return (0);
        }



        public bool Update(Canvas c, Rectangle r)
        {


            Rect r1 = new Rect(Canvas.GetLeft(rect), Canvas.GetTop(rect), rect.ActualWidth, rect.ActualHeight);
            Rect r2 = new Rect(Canvas.GetLeft(r), Canvas.GetTop(r), r.ActualWidth, r.ActualHeight);

            if (r1.IntersectsWith(r2))
            {
                if (c.Children.Contains(rect) && c.Children.Contains(r))
                {
                    health--;
                    if(health == 0)
                    {
                        UnDraw(c);

                    }
                    
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }




        public void Draw(Canvas c)
        {
            if (!c.Children.Contains(rect))
            {
                c.Children.Add(rect);
                c.Children.Add(gun);
            }
        }

        public void UnDraw(Canvas c)
        {
            if (c.Children.Contains(rect))
            { 
                c.Children.Remove(rect);
                c.Children.Remove(gun);
                
            }
        }


        


    }
}
